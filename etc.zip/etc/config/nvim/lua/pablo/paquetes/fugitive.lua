return {
	'tpope/vim-fugitive',
	config = function()
		vim.keymap.set('n', '<Leader>gs', vim.cmd.Git)
	end
}
