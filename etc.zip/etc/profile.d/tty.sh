#!/bin/sh
[ "$(tty)" = "/dev/tty1" ] && startx &>/dev/null
