export PATH=$PATH:/usr/lib/rustup/bin
