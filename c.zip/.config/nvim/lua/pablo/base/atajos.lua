local at = vim.keymap.set
vim.g.mapleader = ' '

at('n', '<Leader>pv', vim.cmd.Ex)

at('n', 'gd', 'gdzz')

at('n', '<Leader><F1>', '<CMD>lua Apuntes()<CR>', { noremap=true, silent=true })
at('n', '<F1>', '<CMD>lua Doctrina()<CR>', { noremap=true, silent=true })

at('n', 'ñ', vim.cmd.w, { noremap=true, silent=true })
at('n', 'Ñ', ':lua Formatear()<CR>', { noremap=true, silent=true })
at('n', '<F5>', ':lua Ejecutar()<CR>', { noremap=true })
at('n', '<F6>', ':lua Compilar()<CR>', { noremap=true })
at('n', '<F7>', ':lua Testear()<CR>', { noremap=true })
at('n', '<F8>', ':lua Limpiar()<CR>', { noremap=true, silent=true })

at('n', '<C-q>', ':q!<CR>', { noremap=true, silent=true })
at({'n', 'i', 'v'}, '<C-x>', vim.cmd.x)
at('n', '<Leader>s', ':%s/', { noremap=true })
at('v', '<Leader>s', ':s/', { noremap=true })

at('n', 'gq', 'mq@q`q')

-- at('i', '<C-j>', '\\x1b[', { noremap=true })

-- Ventanas
at('n', '<C-m>', '<C-w><')
at('n', '<C-n>', '<C-w><')
at('n', '<C-h>', '<C-w>h')
at('n', '<C-l>', '<C-w>l')

at('n', '<Leader>fj', ':%!jq . --tab<CR>', { noremap=true })
at('n', '<Leader>fe', ':%s/\\n\\s*/<CR>', { noremap=true })
at('n', '<Leader>qe', ':%s/[ \\t\\n]//g<CR>', { noremap=true })

at('n', 'º', ':set wrap!<CR>')

-- Quitar espacios finales
at('n', '<Leader>t', '<Cmd>%s/\\s*$<Cr>', { noremap=true })

-- Añadir cierre
at('i', '(', '()<Left>')
at('i', '[', '[]<Left>')
at('i', '[<Space>', '[  ]<Left><Left>')
at('i', '{', '{}<Left>')
at('i', '{<CR>', '{}<Left><CR><Esc>O')
at('i', '"', '""<Left>')
at('i', '¡', '¡!<Left>')
at('i', '¿', '¿?<Left>')

-- Insertar entre signos
at('v', '<Leader>(', 's()<Esc>P')
at('v', '<Leader>[', 's[]<Esc>P')
at('v', '<Leader>{', 's{}<Esc>P')
at('v', '<Leader>"', 's""<Esc>P')
at('v', "<Leader>'", "s''<Esc>P")
at('v', '<Leader>¡', 's¡!<Esc>P')
at('v', '<Leader>¿', 's¿?<Esc>P')

-- Cambiar palabra
at('n', '<C-s>', '"_ciw')


-- Abrir terminal
at('n', '<Leader>t', vim.cmd.term)

-- Útiles
at('n', '<Leader>v', ':!sxiv -bs f % &<CR><CR>')

-- Mover líneas
at('n', '<A-j>', "V:m '>+1<CR>gv=gv<Esc>")
at('n', '<A-k>', "V:m '<-2<CR>gv=gv<Esc>")
at('v', '<A-j>', ":m '>+1<CR>gv=gv")
at('v', '<A-k>', ":m '<-2<CR>gv=gv")

-- Ajustes de navegación
at('n', '<C-d>', '<C-d>zz')
at('n', '<C-u>', '<C-u>zz')
at('n', 'n', 'nzzzv')
at('n', 'N', 'Nzzzv')

-- Mejoras de vida
at('n', 'J', 'mzJ`z')

at('x', '<Leader>p', '"_dP')
at({'n', 'v'}, '<Leader>y', '"+y')
at('n', '<Leader>Y', '"+Y')
at({'n', 'v'}, '<Leader>d', '"_d')

at('n', '<Leader>x', '<cmd>!chmod +x %<CR>')
