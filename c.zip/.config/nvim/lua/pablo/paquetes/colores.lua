return {
	'sainnhe/gruvbox-material',
	config = function()
		vim.cmd('colorscheme gruvbox-material')
		local hl = vim.api.nvim_set_hl
		hl(0, 'Normal', {ctermbg='none'})
		hl(0, 'NormalFloat', {ctermbg='none'})
		hl(0, 'NormalNC', {ctermbg='none'})
		hl(0, 'EndOfBuffer', {ctermbg='none'})
		hl(0, 'Visual', {ctermbg=240})
		hl(0, 'MatchParen', {ctermfg=46, ctermbg='none', bold=true})
		hl(0, 'CursorLine', {ctermfg=237})
		hl(0, 'CursorLineNr', {ctermfg=254})
		hl(0, 'CursorLineFold', {ctermfg=12, bold=true})
		hl(0, 'LineNr', {ctermfg=246})
		hl(0, 'Folded', {ctermfg=4, ctermbg=0})
		hl(0, 'TabLine', {ctermfg=1, ctermbg=1})
		hl(0, 'TabLineFill', {ctermbg=0})
		hl(0, 'FloatBorder', {ctermbg=0})
		hl(0, 'FloatTitle', {ctermfg=5, ctermbg=0})
		hl(0, 'AZ', {ctermfg=0, ctermbg=4, bold=true})
		hl(0, 'VE', {ctermfg=0, ctermbg=2, bold=true})
		hl(0, 'AM', {ctermfg=0, ctermbg=3, bold=true})
		hl(0, 'RO', {ctermfg=0, ctermbg=1, bold=true})
		hl(0, 'MA', {ctermfg=0, ctermbg=5, bold=true})
		hl(0, 'CI', {ctermfg=0, ctermbg=6, bold=true})
	end
}
